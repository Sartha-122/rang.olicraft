# Rang Olicraft Website

This static website was customized from the flyer information for `रंग.ओलिक्राफ्ट`.

## Business Details Used

- Business name: `रंग.ओलिक्राफ्ट`
- Product: `Handmade Woolen Rangoli Mat`
- WhatsApp / phone: `8605569065`
- Instagram: `https://www.instagram.com/rang.olicraft?stkn=bTA2cXczaHN1MmNz`
- Uses: home decor, pooja room, gifting, custom designs
- Highlights: high-quality woolen thread, durable, attractive designs, low maintenance

## Files

- `index.html` contains the page content.
- `styles.css` controls the design and responsive layout.
- `script.js` opens WhatsApp with the order form details.
- `assets/rang-olicraft-flyer.jpg` is cropped from the provided business flyer.

## Quick Edits

1. Update prices if you want to show pricing.
2. Replace the Instagram link if your profile URL changes.
3. Add more product photos in the `assets` folder and place them in `index.html`.
