const body = document.body;
const navToggle = document.querySelector(".nav-toggle");
const siteNav = document.querySelector(".site-nav");
const year = document.querySelector("#year");
const form = document.querySelector("#contact-form");
const formStatus = document.querySelector("#form-status");
const whatsappNumber = "918605569065";

year.textContent = new Date().getFullYear();

navToggle.addEventListener("click", () => {
  const isOpen = body.classList.toggle("nav-open");
  navToggle.setAttribute("aria-expanded", String(isOpen));
});

siteNav.addEventListener("click", (event) => {
  if (event.target.matches("a")) {
    body.classList.remove("nav-open");
    navToggle.setAttribute("aria-expanded", "false");
  }
});

form.addEventListener("submit", (event) => {
  event.preventDefault();

  const formData = new FormData(form);
  const name = formData.get("name");
  const phone = formData.get("phone");
  const design = formData.get("design");
  const message = formData.get("message") || "Please share available designs and price.";

  const text = encodeURIComponent(
    `Namaste Rang Olicraft,\n\nName: ${name}\nMobile: ${phone}\nInterested Design: ${design}\nMessage: ${message}`
  );

  formStatus.textContent = "Opening WhatsApp...";
  window.open(`https://wa.me/${whatsappNumber}?text=${text}`, "_blank", "noopener,noreferrer");
});
